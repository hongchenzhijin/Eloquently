
import { WordEntry } from '../types';

export const ADVANCED_VOCABULARY: WordEntry[] = [
  {
    id: '1',
    word: 'Ephemeral',
    phonetic: '/əˈfem(ə)rəl/',
    partOfSpeech: 'adjective',
    definition: 'Lasting for a very short time.',
    example: 'The beauty of the sunset was ephemeral, fading into twilight within minutes.',
    etymology: 'From Greek ephēmeros, from epi ‘upon’ + hēmera ‘day’.'
  },
  {
    id: '2',
    word: 'Pernicious',
    phonetic: '/pərˈniSHəs/',
    partOfSpeech: 'adjective',
    definition: 'Having a harmful effect, especially in a gradual or subtle way.',
    example: 'The pernicious influence of social media on self-esteem is a growing concern for psychologists.',
    etymology: 'From Latin perniciosus ‘destructive’.'
  },
  {
    id: '3',
    word: 'Alacrity',
    phonetic: '/əˈlakrədē/',
    partOfSpeech: 'noun',
    definition: 'Brisk and cheerful readiness.',
    example: 'She accepted the invitation with alacrity, excited by the prospect of a new adventure.',
    etymology: 'From Latin alacritas, from alacer ‘lively, eager’.'
  },
  {
    id: '4',
    word: 'Enervate',
    phonetic: '/ˈenərˌvāt/',
    partOfSpeech: 'verb',
    definition: 'To cause someone to feel drained of energy or vitality; weaken.',
    example: 'The intense heat of the desert sun served to enervate the weary travelers.',
    etymology: 'From Latin enervat- ‘weakened’, from the verb enervare.'
  },
  {
    id: '5',
    word: 'Magnanimous',
    phonetic: '/maɡˈnanəməs/',
    partOfSpeech: 'adjective',
    definition: 'Generous or forgiving, especially toward a rival or less powerful person.',
    example: 'Despite the fierce competition, the victor was magnanimous in her praise for the runner-up.',
    etymology: 'From Latin magnanimus, from magnus ‘great’ + animus ‘mind’.'
  },
  {
    id: '6',
    word: 'Ubiquitous',
    phonetic: '/yo͞oˈbikwədəs/',
    partOfSpeech: 'adjective',
    definition: 'Present, appearing, or found everywhere.',
    example: 'Mobile phones are now ubiquitous in modern society, bridging gaps across continents.',
    etymology: 'From Latin ubique ‘everywhere’.'
  },
  {
    id: '7',
    word: 'Querulous',
    phonetic: '/ˈkwer(y)ələs/',
    partOfSpeech: 'adjective',
    definition: 'Complaining in a petulant or whining manner.',
    example: 'The querulous passenger spent the entire flight grumbling about the lack of legroom.',
    etymology: 'From Latin querulus, from queri ‘complain’.'
  }
];
