
import { GoogleGenAI, Type } from "@google/genai";
import { EvaluationResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const evaluateSentence = async (word: string, sentence: string): Promise<EvaluationResult> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Evaluate the following sentence using the word "${word}". 
      Sentence: "${sentence}"
      
      Criteria:
      1. Correct usage of the word "${word}".
      2. Grammatical correctness.
      3. Sophistication and context.
      
      Provide a score from 1 to 10. 
      If the score is less than 5, provide a "suggestion" on how to rewrite it more eloquently.
      Always provide "feedback" explaining the score.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            score: {
              type: Type.NUMBER,
              description: "A score from 1 to 10."
            },
            feedback: {
              type: Type.STRING,
              description: "A concise explanation of the score."
            },
            suggestion: {
              type: Type.STRING,
              description: "An improved version of the sentence (mandatory if score < 5)."
            },
            isExcellent: {
              type: Type.BOOLEAN,
              description: "True if score is 8 or higher."
            }
          },
          required: ["score", "feedback", "isExcellent"]
        }
      }
    });

    const result = JSON.parse(response.text || "{}");
    return {
      score: result.score || 0,
      feedback: result.feedback || "Unable to evaluate.",
      suggestion: result.suggestion,
      isExcellent: result.isExcellent || false
    };
  } catch (error) {
    console.error("Evaluation error:", error);
    return {
      score: 0,
      feedback: "There was an error connecting to the evaluation engine. Please try again.",
      isExcellent: false
    };
  }
};
